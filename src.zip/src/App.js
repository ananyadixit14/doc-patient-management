// src/App.js

import React from 'react';
import ErrorBoundary from './components/ErrorBoundary'; // Import ErrorBoundary
import ErrorProneComponent from './components/ErrorProneComponent';
import Home from './components/Home';
import About from './components/About';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
function App() {
  return (
    <ErrorBoundary>
      <Router>
        <Routes>
        <Route path="/error" element={<ErrorProneComponent />} />
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          {/* Other routes */}
        </Routes>
      </Router>
    </ErrorBoundary>
  );
}

export default App;
