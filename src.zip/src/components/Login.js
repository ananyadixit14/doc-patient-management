// src/components/Login.js

import React, { useState } from 'react';
import './Login.css'; // We will create this CSS file for styling

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = (e) => {
        e.preventDefault();
        // Here, you would normally handle the login logic, e.g., API call
        console.log('Login submitted:', { username, password });
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            <form onSubmit={handleLogin}>
                <div className="input-group">
                    <label htmlFor="username">Username</label>
                    <input
                        type="text"
                        id="username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                </div>
                <div className="input-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Login</button>
            </form>
            <div className="login-footer">
                <p>Don't have an account? <a href="/signup">Sign up</a></p>
                <p><a href="/forgot-password">Forgot password?</a></p>
            </div>
        </div>
    );
};

export default Login;
