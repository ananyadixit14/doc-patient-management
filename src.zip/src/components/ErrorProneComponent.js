// src/components/ErrorProneComponent.js

import React from 'react';

function ErrorProneComponent() {
  // Simulate an error
  throw new Error('Simulated error');
  return <div>This will not be rendered.</div>;
}

export default ErrorProneComponent;
