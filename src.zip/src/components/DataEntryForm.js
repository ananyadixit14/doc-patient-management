// src/components/DataEntryForm.js

import React, { useState } from 'react';
import './DataEntryForm.css';

const DataEntryForm = () => {
    const [heartRate, setHeartRate] = useState('');
    const [bloodPressure, setBloodPressure] = useState({ systolic: '', diastolic: '' });
    const [oxygenSaturation, setOxygenSaturation] = useState('');
    const [temperature, setTemperature] = useState('');
    const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
    const [time, setTime] = useState(new Date().toISOString().slice(11, 16));

    const handleSubmit = (e) => {
        e.preventDefault();
        const data = {
            heartRate,
            bloodPressure,
            oxygenSaturation,
            temperature,
            date,
            time,
        };
        console.log('Data submitted:', data);
        // Here, you would typically send the data to the backend API
    };

    return (
        <div className="data-entry-container">
            <h2>Enter Your Vital Signs</h2>
            <form onSubmit={handleSubmit}>
                <div className="input-group">
                    <label htmlFor="heartRate">Heart Rate (bpm)</label>
                    <input
                        type="number"
                        id="heartRate"
                        value={heartRate}
                        onChange={(e) => setHeartRate(e.target.value)}
                        required
                    />
                </div>
                <div className="input-group">
                    <label>Blood Pressure (mmHg)</label>
                    <div className="blood-pressure-inputs">
                        <input
                            type="number"
                            placeholder="Systolic"
                            value={bloodPressure.systolic}
                            onChange={(e) =>
                                setBloodPressure({ ...bloodPressure, systolic: e.target.value })
                            }
                            required
                        />
                        <input
                            type="number"
                            placeholder="Diastolic"
                            value={bloodPressure.diastolic}
                            onChange={(e) =>
                                setBloodPressure({ ...bloodPressure, diastolic: e.target.value })
                            }
                            required
                        />
                    </div>
                </div>
                <div className="input-group">
                    <label htmlFor="oxygenSaturation">Oxygen Saturation (%)</label>
                    <input
                        type="number"
                        id="oxygenSaturation"
                        value={oxygenSaturation}
                        onChange={(e) => setOxygenSaturation(e.target.value)}
                        required
                    />
                </div>
                <div className="input-group">
                    <label htmlFor="temperature">Temperature (°C)</label>
                    <input
                        type="number"
                        id="temperature"
                        value={temperature}
                        onChange={(e) => setTemperature(e.target.value)}
                        required
                    />
                </div>
                <div className="input-group">
                    <label htmlFor="date">Date</label>
                    <input
                        type="date"
                        id="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        required
                    />
                </div>
                <div className="input-group">
                    <label htmlFor="time">Time</label>
                    <input
                        type="time"
                        id="time"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default DataEntryForm;
